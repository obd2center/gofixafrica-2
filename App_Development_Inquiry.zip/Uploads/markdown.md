```markdown
# AutoAfrica Marketplace – MVP Architecture

## 1. Overview

This document describes the **MVP architecture** for the AutoAfrica Marketplace, based on:

- Product spec in `AutoAfrica_Product_Development_Structure_v2.docx`
- AWS-based infrastructure with:
  - **CloudFront + ALB + ECS Fargate**
  - **Next.js frontend**
  - **NestJS backend**
  - **PostgreSQL (RDS) + PostGIS**
  - **Redis (ElastiCache)**
  - **S3 for file storage**

The goal is a **single-region**, scalable MVP that supports **multi-country subdomains** (e.g. `ke.autoafrica.com`, `ng.autoafrica.com`) through **logical regionalization** (one AWS region, many markets).

---

## 2. High-Level Architecture

### 2.1 Logical Layers

1. **Client**
   - Web browsers + PWA (mobile-first).
   - Single URL space: `https://{region}.autoafrica.com`.

2. **Edge & Routing**
   - **Route 53** – DNS for `autoafrica.com` + `*.autoafrica.com`.
   - **CloudFront** – CDN, TLS termination, caching.
   - **Application Load Balancer (ALB)** – Routes traffic to frontend/backend.

3. **Application Services (ECS Fargate)**
   - `web-service` – Next.js 14 (SSR, PWA, UI/UX).
   - `api-service` – NestJS (REST API, business logic).

4. **Data & Storage**
   - **RDS PostgreSQL** (+ PostGIS).
   - **ElastiCache Redis**.
   - **S3** – images, ECU files, uploads.

5. **External Integrations**
   - Payments – Flutterwave / Paystack / M-Pesa.
   - Email – SES (or third-party).
   - SMS/OTP – SNS or local SMS aggregator.

---

## 3. Domain & Subdomain Strategy

### 3.1 DNS (Route 53)

Hosted zone: `autoafrica.com`.

Records:

- `autoafrica.com` → CloudFront distribution (A/AAAA alias).
- `*.autoafrica.com` → same CloudFront distribution (wildcard).

Examples:

- `ke.autoafrica.com` – Kenya region.
- `ng.autoafrica.com` – Nigeria region.
- `za.autoafrica.com` – South Africa region.

The **Host header** (`ke.autoafrica.com`, etc.) is preserved end-to-end and used for region detection.

### 3.2 Region & Localization Logic

- No separate infra per country for MVP.
- **Single logical system** with region-awareness:
  - Frontend (Next.js) reads `Host` → sets `region` and default `language`.
  - Backend (NestJS) reads `Host` → loads `region` record from DB:
    - Default currency.
    - Available payment methods.
    - Country/language defaults.
- `regions` table in Postgres holds configuration for:
  - `country_code`, `subdomain`, `default_language`, `default_currency`, `payment_methods`, `is_active`.

---

## 4. Networking & VPC Layout

### 4.1 VPC

- **VPC CIDR:** `10.0.0.0/16` (example)
- **Subnets:**
  - Public Subnet A / B – ALB, NAT gateways.
  - Private App Subnet A / B – ECS Fargate tasks.
  - Private Data Subnet A / B – RDS, ElastiCache (and later OpenSearch).

### 4.2 Security Groups (High-level)

- **ALB SG**
  - Inbound: `0.0.0.0/0` on `80`, `443`.
  - Outbound: to ECS tasks SG on app ports.

- **ECS SG**
  - Inbound: from ALB SG on app ports (e.g. `3000` for web, `4000` for API).
  - Outbound: to RDS SG, Redis SG, S3, internet via NAT.

- **RDS SG**
  - Inbound: from ECS SG on Postgres port (`5432`).

- **Redis SG**
  - Inbound: from ECS SG on Redis port (`6379`).

---

## 5. Edge Layer: CloudFront + ALB

### 5.1 CloudFront Distribution

- **Origins:**
  - Origin: ALB DNS, e.g. `autoafrica-alb-xxxx.region.elb.amazonaws.com`.

- **Behaviors:**
  - Default behavior: `/*` → ALB, with:
    - Forwarded headers: `Host`, `Authorization`, `Accept-Language`, etc.
    - Cached paths longer for static assets (`/_next/static/*`, images).
    - Short TTL / no cache for dynamic HTML & `/api/*`.

- **TLS:**
  - ACM certificate for `autoafrica.com` and `*.autoafrica.com`.

### 5.2 Application Load Balancer (ALB)

- **Listeners:**
  - HTTP (80) → redirect to HTTPS (443).
  - HTTPS (443) → routes based on path.

- **Target Groups:**
  - `web-tg` → `web-service` (Next.js).
  - `api-tg` → `api-service` (NestJS).

- **Routing Rules:**
  - If path is `/api/*` → `api-tg`.
  - Else (`/*`) → `web-tg`.

- **Health Checks:**
  - `web-tg`: e.g. `GET /health` (Next.js health route).
  - `api-tg`: `GET /api/health` (NestJS health route).

---

## 6. Application Layer: ECS Fargate Services

### 6.1 Common

- **Cluster:** `autoafrica-main-cluster`.
- **Launch type:** Fargate.
- **Deployment:** GitHub Actions (or similar) pushes Docker images to ECR; ECS services updated via CI/CD.

### 6.2 `web-service` (Next.js 14)

- **Image:** `autoafrica-web:<tag>` (stored in ECR).
- **Tasks:** 2–N tasks across AZs.
- **Port:** 3000 (example).
- **Responsibilities:**
  - App splash screen + landing page (three floating tabs).
  - SSR pages: home, listings, provider profiles, ECU showcase, etc.
  - PWA shell (service worker, offline caching).
  - Responsive UI, animations (Framer Motion, Lottie).
  - Calls backend via `/api/*`.
  - Reads `Host` header via Next middleware to determine region & language.

### 6.3 `api-service` (NestJS)

- **Image:** `autoafrica-api:<tag>` (in ECR).
- **Tasks:** 2–N tasks across AZs.
- **Port:** 4000 (example).
- **Responsibilities:**
  - Auth:
    - JWT-based auth (access + refresh tokens).
    - OTP verification via SMS.
    - Social login (Google/Facebook/Apple) as needed.
  - User & Provider Management:
    - Roles: Customer, Service Provider, Parts Trader.
    - Provider verification, documents, photos, locations.
  - Services & Bookings:
    - Service catalogs.
    - Booking and inquiry flows.
  - Parts Marketplace:
    - Product listings (new/used/refurb).
    - RFQ for B2B.
  - Reviews & Ratings:
    - 5-star ratings, category breakdown.
    - Verifications tied to bookings/orders.
  - ECU & File Services:
    - ECU orders, S3 file handling via pre-signed URLs.
    - Status tracking (uploaded, in-progress, completed).
  - Localization & Regions:
    - Reads `Host` → maps to `region` record.
    - Applies region defaults (currency, language, payment methods).
  - Payments:
    - Integrates with Flutterwave/Paystack/M-Pesa.
    - Handles payment initiation endpoint and webhook handlers.
  - Notifications:
    - Email via SES.
    - SMS via SNS or external aggregator.

---

## 7. Data & Storage Layer

### 7.1 RDS PostgreSQL (+ PostGIS)

- **Service:** Amazon RDS, engine PostgreSQL.
- **Features:**
  - Multi-AZ for high availability.
  - PostGIS extension for geospatial queries.
- **Sample core tables:**
  - `users`
  - `service_providers`
  - `categories`
  - `locations` (with `lat`, `lng`, `geom`)
  - `services`
  - `products`
  - `bookings`
  - `reviews`
  - `regions`
  - `ecu_files`
- **ORM:** TypeORM or Prisma via NestJS.

### 7.2 ElastiCache Redis

- **Service:** Redis cluster in private subnets.
- **Usage:**
  - Caching hot queries (popular providers, parts, etc.).
  - Storing short-lived tokens, OTP codes (if not via JWT only).
  - Rate-limiting counters.

### 7.3 S3 for Files

- **Bucket:** `autoafrica-uploads-prod` (example).
  - Private by default.
  - Folders:
    - `provider-logos/`
    - `provider-photos/`
    - `ecu-original/`
    - `ecu-modified/`

- **Access Pattern:**
  - NestJS generates **pre-signed URLs** for upload/download.
  - Frontend uploads ECU files and images **directly to S3** via pre-signed URL.
  - Downloads via short-lived pre-signed URL or via CloudFront if public assets.

---

## 8. Localization & Multi-Region Behavior

### 8.1 Frontend (Next.js)

- Use `next-intl` or `next-i18next`.
- **Next.js middleware:**
  - Reads `request.headers.host` (`ke.autoafrica.com`).
  - Maps subdomain → region code (e.g., `ke` → `KE` region).
  - Sets default `locale` based on region.

- **Dynamic text:**
  - Localized strings via `.json`/`.po` per language.
  - `hrefLang` tags for SEO across regions and languages.

### 8.2 Backend (NestJS)

- **Global interceptor/middleware:**
  - Reads `Host` header from incoming request.
  - Queries `regions` table to get region config.
  - Attaches `req.region` (or similar) for downstream handlers:
    - Filter providers, services, products by `region_id`.
    - Choose currency (KES, NGN, ZAR).
    - Select valid payment methods.

---

## 9. Payments & Webhooks

### 9.1 Initiating Payment

1. Frontend calls `POST /api/payments/create`.
2. NestJS:
   - Creates `booking`/`order` with `status='pending'`.
   - Calls Flutterwave/Paystack/M-Pesa API to create payment session/link.
   - Returns payment link or client client-side parameters.
3. Frontend redirects the user to hosted payment page or embeds payment widget.

### 9.2 Handling Webhooks

- Payment provider sends webhook → `POST /api/payments/webhook`.
- ALB → `api-tg` → ECS `api-service`.
- NestJS:
  - Validates signature / HMAC.
  - Looks up associated `order_id`.
  - Updates `status` to `paid` (or `failed`).
  - Triggers:
    - Email confirmation (SES).
    - Provider/customer notifications (SMS, email, in-app).

---

## 10. DevOps & CI/CD

### 10.1 Repositories & Build

- **Recommended structure:** Monorepo (e.g., Turborepo) with:
  - `apps/web` – Next.js.
  - `apps/api` – NestJS.
  - `packages/shared` – shared types, DTOs, utils.

### 10.2 CI/CD Pipeline

**GitHub Actions / GitLab CI**:

- **On push to main:**
  1. Lint + tests (for both web and api).
  2. Build Docker images:
     - `autoafrica-web:<git_sha>`.
     - `autoafrica-api:<git_sha>`.
  3. Push images to ECR.
  4. Update ECS services (using task definition revisions).
  5. Run smoke tests / health checks.

### 10.3 Observability

- **CloudWatch Logs** for ECS tasks.
- **Metrics & alarms:**
  - CPU/memory for ECS services.
  - RDS metrics (connections, CPU, IOPS).
  - ALB 4xx/5xx error rates.
- **Error tracking:** e.g., Sentry for frontend + backend.

---

## 11. MVP Scope Coverage

This architecture supports the MVP features described in the product spec:

- **Core:**
  - Service provider onboarding, listings, booking.
  - Parts marketplace.
  - ECU & diagnostics file services.
  - Rating & review system.
- **Localization:**
  - Subdomain-based regions, multi-language support (English, Swahili, French).
- **Performance:**
  - SSR for SEO and fast first paint.
  - CloudFront CDN and caching.
- **Scalability:**
  - ECS Fargate with autoscaling.
  - RDS with Multi-AZ.
  - Redis caching.
- **Security:**
  - Private subnets for app & data.
  - S3 private buckets with pre-signed URLs.
  - JWT, OTP, and secure payment flows.

This is intended as the **baseline architectural blueprint** for the MVP. Future phases (mobile apps, B2B wholesale expansion, OpenSearch integration, AI-based diagnostics) can be layered on top without major redesign.
```