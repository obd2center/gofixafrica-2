#!/bin/bash

# AutoAfrica Marketplace - Push to GitHub Script
# This script helps you push your code to GitHub

echo "========================================="
echo "AutoAfrica Marketplace - GitHub Push"
echo "========================================="
echo ""

# Check if we're in the right directory
if [ ! -d ".git" ]; then
    echo "❌ Error: Not a git repository"
    exit 1
fi

echo "📦 Repository: https://github.com/obd2center/gofixafrica-2"
echo "🌳 Branch: main"
echo ""

# Show current status
echo "📊 Current status:"
git status --short
echo ""

# Show commits ready to push
echo "📝 Commits ready to push:"
git log --oneline origin/main..main 2>/dev/null || git log --oneline -3
echo ""

echo "========================================="
echo "Choose your push method:"
echo "========================================="
echo "1. Push with GitHub Token (recommended)"
echo "2. Push with GitHub Username/Password"
echo "3. Configure SSH and push"
echo "4. Exit"
echo ""
read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo ""
        echo "🔑 Enter your GitHub Personal Access Token:"
        echo "(The token must have 'repo' scope)"
        read -s token
        echo ""
        echo "🚀 Pushing to GitHub..."
        git push https://$token@github.com/obd2center/gofixafrica-2.git main
        ;;
    2)
        echo ""
        echo "⚠️  Note: GitHub no longer accepts passwords for git operations."
        echo "Please use a Personal Access Token instead (Option 1)"
        echo ""
        echo "To create a token:"
        echo "1. Go to https://github.com/settings/tokens/new"
        echo "2. Check the 'repo' scope"
        echo "3. Generate and copy the token"
        ;;
    3)
        echo ""
        echo "🔐 SSH Push Setup:"
        echo "1. Generate SSH key: ssh-keygen -t ed25519 -C 'your_email@example.com'"
        echo "2. Copy public key: cat ~/.ssh/id_ed25519.pub"
        echo "3. Add to GitHub: https://github.com/settings/keys"
        echo "4. Change remote: git remote set-url origin git@github.com:obd2center/gofixafrica-2.git"
        echo "5. Push: git push -u origin main"
        ;;
    4)
        echo "👋 Exiting..."
        exit 0
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac
