"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Navbar } from "@/components/navbar";
import {
  Wrench,
  Package,
  Cpu,
  Star,
  MapPin,
  Shield,
  TrendingUp,
  Users,
  ArrowRight,
} from "lucide-react";

export default function HomePage() {
  const features = [
    {
      icon: Wrench,
      title: "Service Providers",
      description: "Connect with verified mechanics, garages, and automotive service experts across Africa",
      link: "/services",
      color: "text-blue-500",
      bgColor: "bg-blue-50",
    },
    {
      icon: Package,
      title: "Parts Marketplace",
      description: "Find genuine and quality auto parts from trusted traders. Request quotes for specific needs",
      link: "/parts",
      color: "text-green-500",
      bgColor: "bg-green-50",
    },
    {
      icon: Cpu,
      title: "ECU Services",
      description: "Professional ECU remapping, tuning, and diagnostic file services for optimal vehicle performance",
      link: "/ecu",
      color: "text-purple-500",
      bgColor: "bg-purple-50",
    },
  ];
  
  const benefits = [
    { icon: Shield, title: "Verified Partners", description: "All service providers and traders are verified" },
    { icon: Star, title: "Quality Ratings", description: "Transparent reviews from real customers" },
    { icon: MapPin, title: "Local & Regional", description: "Find services in your area across Africa" },
    { icon: TrendingUp, title: "Best Prices", description: "Compare quotes and get competitive pricing" },
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 via-white to-blue-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Your Complete <span className="text-orange-500">Automotive</span> Marketplace
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Connecting drivers with quality services, genuine parts, and expert diagnostics across Africa
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup">
              <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-lg px-8">
                Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/services">
              <Button size="lg" variant="outline" className="text-lg px-8">
                Explore Services
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>
      
      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {features?.map((feature, index) => {
            const Icon = feature?.icon ?? Wrench;
            return (
              <motion.div
                key={feature?.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Link href={feature?.link ?? '#'}>
                  <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                    <CardContent className="p-6">
                      <div className={`${feature?.bgColor ?? 'bg-gray-50'} p-4 rounded-lg inline-block mb-4`}>
                        <Icon className={`w-8 h-8 ${feature?.color ?? 'text-gray-500'}`} />
                      </div>
                      <h3 className="text-xl font-bold mb-2">{feature?.title ?? ''}</h3>
                      <p className="text-gray-600">{feature?.description ?? ''}</p>
                      <div className="mt-4 flex items-center text-orange-500 font-medium">
                        Learn more <ArrowRight className="ml-2 w-4 h-4" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>
      </section>
      
      {/* Benefits Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose AutoAfrica?</h2>
            <p className="text-xl text-gray-600">Trusted by thousands across the continent</p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits?.map((benefit, index) => {
              const Icon = benefit?.icon ?? Shield;
              return (
                <motion.div
                  key={benefit?.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="bg-orange-100 p-4 rounded-full inline-block mb-4">
                    <Icon className="w-8 h-8 text-orange-500" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">{benefit?.title ?? ''}</h3>
                  <p className="text-gray-600">{benefit?.description ?? ''}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-12 text-center text-white"
        >
          <Users className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Join Our Growing Community
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Whether you're a customer, service provider, or parts trader
          </p>
          <Link href="/auth/signup">
            <Button size="lg" variant="secondary" className="text-lg px-8">
              Create Your Account
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </motion.div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400">
            © 2025 AutoAfrica. Connecting Africa's automotive ecosystem.
          </p>
        </div>
      </footer>
    </div>
  );
}