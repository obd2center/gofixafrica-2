import { getServerSession } from "next-auth";
import { Navbar } from "@/components/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Cpu, Upload, Download, Zap, Shield, Clock, Check } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ECUPage() {
  const session = await getServerSession();
  
  const services = [
    {
      title: 'ECU Remapping',
      description: 'Optimize your engine performance with professional ECU remapping services',
      icon: Cpu,
      features: ['Increased Power', 'Better Fuel Economy', 'Smoother Driving'],
      price: 'From $150',
    },
    {
      title: 'DPF Removal',
      description: 'Safe and professional DPF removal and delete services',
      icon: Zap,
      features: ['Improved Performance', 'Reduced Maintenance', 'Better Efficiency'],
      price: 'From $200',
    },
    {
      title: 'EGR Delete',
      description: 'EGR valve delete and modification services',
      icon: Shield,
      features: ['Cleaner Engine', 'Better Response', 'Extended Life'],
      price: 'From $100',
    },
  ];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl p-12 text-white mb-8">
            <Cpu className="w-16 h-16 mx-auto mb-4" />
            <h1 className="text-4xl font-bold mb-4">
              Professional ECU & Diagnostic Services
            </h1>
            <p className="text-xl opacity-90 mb-6">
              Upload your ECU files and get professional remapping services
            </p>
            {session ? (
              <Link href="/ecu/new">
                <Button size="lg" variant="secondary" className="text-lg px-8">
                  <Upload className="w-5 h-5 mr-2" />
                  Upload ECU File
                </Button>
              </Link>
            ) : (
              <Link href="/auth/signup">
                <Button size="lg" variant="secondary" className="text-lg px-8">
                  Get Started
                </Button>
              </Link>
            )}
          </div>
        </div>
        
        {/* Services */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {services?.map((service) => {
              const Icon = service?.icon ?? Cpu;
              return (
                <Card key={service?.title} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="bg-purple-100 p-3 rounded-lg inline-block mb-2">
                      <Icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <CardTitle>{service?.title ?? ''}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{service?.description ?? ''}</p>
                    <ul className="space-y-2 mb-4">
                      {service?.features?.map((feature) => (
                        <li key={feature} className="flex items-center text-sm">
                          <Check className="w-4 h-4 text-green-500 mr-2" />
                          {feature ?? ''}
                        </li>
                      ))}
                    </ul>
                    <p className="text-lg font-bold text-purple-600">{service?.price ?? ''}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
        
        {/* How It Works */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="bg-purple-100 p-4 rounded-full inline-block mb-3">
                  <Upload className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">1. Upload File</h3>
                <p className="text-sm text-gray-600">Upload your original ECU file securely</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 p-4 rounded-full inline-block mb-3">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">2. Processing</h3>
                <p className="text-sm text-gray-600">Our experts analyze and modify your file</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 p-4 rounded-full inline-block mb-3">
                  <Shield className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">3. Quality Check</h3>
                <p className="text-sm text-gray-600">Rigorous testing and quality assurance</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 p-4 rounded-full inline-block mb-3">
                  <Download className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">4. Download</h3>
                <p className="text-sm text-gray-600">Receive your modified file ready to flash</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* CTA */}
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">
            Ready to Optimize Your Vehicle?
          </h2>
          <p className="mb-6 opacity-90">
            Join thousands of satisfied customers who trust our ECU services
          </p>
          {session ? (
            <Link href="/ecu/new">
              <Button size="lg" variant="secondary">
                <Upload className="w-5 h-5 mr-2" />
                Start Your Order
              </Button>
            </Link>
          ) : (
            <Link href="/auth/signup">
              <Button size="lg" variant="secondary">
                Create Account
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}