import { prisma } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { Star, MapPin, Clock, DollarSign, Phone, Mail } from "lucide-react";
import { getCurrencySymbol } from "@/lib/region";
import { getServerSession } from "next-auth";

export const dynamic = "force-dynamic";

export default async function ServiceDetailPage({ params }: { params: { slug: string } }) {
  const service = await prisma.service.findFirst({
    where: {
      OR: [
        { slug: params?.slug },
        { id: params?.slug },
      ],
    },
    include: {
      provider: {
        include: {
          region: true,
        },
      },
      category: true,
    },
  });
  
  if (!service) {
    notFound();
  }
  
  const session = await getServerSession();
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-0">
                <div className="relative h-96 w-full">
                  <Image
                    src={service?.images?.[0] ?? '/placeholder.jpg'}
                    alt={service?.name ?? 'Service'}
                    fill
                    className="object-cover rounded-t-lg"
                    sizes="(max-width: 768px) 100vw, 66vw"
                  />
                </div>
                
                <div className="p-8">
                  <div className="mb-4">
                    <span className="text-sm bg-orange-100 text-orange-700 px-3 py-1 rounded-full">
                      {service?.category?.name ?? ''}
                    </span>
                  </div>
                  
                  <h1 className="text-3xl font-bold mb-4">{service?.name ?? ''}</h1>
                  
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-500 fill-yellow-500 mr-1" />
                      <span className="font-semibold text-lg">{service?.rating?.toFixed(1) ?? '0.0'}</span>
                      <span className="text-gray-500 ml-1">({service?.totalReviews ?? 0} reviews)</span>
                    </div>
                  </div>
                  
                  <div className="prose max-w-none mb-8">
                    <p className="text-gray-700 text-lg leading-relaxed">
                      {service?.description ?? ''}
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    {service?.duration && (
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-3 rounded-lg mr-3">
                          <Clock className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Duration</p>
                          <p className="font-semibold">{service.duration}</p>
                        </div>
                      </div>
                    )}
                    {service?.price && (
                      <div className="flex items-center">
                        <div className="bg-green-100 p-3 rounded-lg mr-3">
                          <DollarSign className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Price</p>
                          <p className="font-semibold text-lg">
                            {getCurrencySymbol(service?.provider?.region?.defaultCurrency ?? 'USD')} {service.price?.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Sidebar */}
          <div>
            <Card className="sticky top-20">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Service Provider</h3>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-lg mb-2">{service?.provider?.businessName ?? ''}</h4>
                  {service?.provider?.isVerified && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                      ✓ Verified Provider
                    </span>
                  )}
                </div>
                
                <div className="space-y-3 mb-6">
                  {service?.provider?.phone && (
                    <div className="flex items-center text-sm">
                      <Phone className="w-4 h-4 mr-2 text-gray-500" />
                      <span>{service.provider.phone}</span>
                    </div>
                  )}
                  {service?.provider?.email && (
                    <div className="flex items-center text-sm">
                      <Mail className="w-4 h-4 mr-2 text-gray-500" />
                      <span>{service.provider.email}</span>
                    </div>
                  )}
                  {service?.provider?.address && (
                    <div className="flex items-start text-sm">
                      <MapPin className="w-4 h-4 mr-2 text-gray-500 mt-0.5" />
                      <span>{service.provider.address}</span>
                    </div>
                  )}
                </div>
                
                {session ? (
                  <Button className="w-full bg-orange-500 hover:bg-orange-600" size="lg">
                    Book Now
                  </Button>
                ) : (
                  <Link href="/auth/login" className="block">
                    <Button className="w-full bg-orange-500 hover:bg-orange-600" size="lg">
                      Sign in to Book
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
