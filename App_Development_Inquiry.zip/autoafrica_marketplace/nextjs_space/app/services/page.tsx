import { prisma } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { Star, MapPin, Clock, DollarSign } from "lucide-react";
import { getCurrencySymbol } from "@/lib/region";

export const dynamic = "force-dynamic";

export default async function ServicesPage() {
  // Fetch all services with provider and category info
  const services = await prisma.service.findMany({
    where: { isActive: true },
    include: {
      provider: {
        include: {
          region: true,
        },
      },
      category: true,
    },
    orderBy: { rating: 'desc' },
    take: 20,
  });
  
  const categories = await prisma.category.findMany({
    where: { isActive: true, parentId: null },
    orderBy: { name: 'asc' },
  });
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Automotive Services
          </h1>
          <p className="text-gray-600">
            Connect with verified service providers across Africa
          </p>
        </div>
        
        
        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services?.map((service) => (
            <Link key={service?.id} href={`/services/${service?.slug ?? service?.id}`}>
              <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                <div className="relative h-48 w-full">
                  <Image
                    src={service?.images?.[0] ?? '/placeholder.jpg'}
                    alt={service?.name ?? 'Service'}
                    fill
                    className="object-cover rounded-t-lg"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="mb-2">
                    <span className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded-full">
                      {service?.category?.name ?? ''}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2 line-clamp-1">
                    {service?.name ?? ''}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {service?.description ?? ''}
                  </p>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-2" />
                      {service?.provider?.businessName ?? ''}
                    </div>
                    {service?.duration && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="w-4 h-4 mr-2" />
                        {service.duration}
                      </div>
                    )}
                    {service?.price && (
                      <div className="flex items-center text-sm font-semibold text-orange-600">
                        <DollarSign className="w-4 h-4 mr-1" />
                        {getCurrencySymbol(service?.provider?.region?.defaultCurrency ?? 'USD')} {service.price?.toLocaleString()}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500 mr-1" />
                      <span className="font-semibold">{service?.rating?.toFixed(1) ?? '0.0'}</span>
                      <span className="text-gray-500 text-sm ml-1">({service?.totalReviews ?? 0})</span>
                    </div>
                    {service?.provider?.isVerified && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                        Verified
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
        
        {services?.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No services found. Check back soon!</p>
          </div>
        )}
      </div>
    </div>
  );
}