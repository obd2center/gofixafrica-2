// Signup API Route
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { UserRole } from '@prisma/client';

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name, phone, role, country } = body ?? {};
    
    // Validate required fields
    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });
    
    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 400 }
      );
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Determine user role
    const userRole = role as UserRole ?? UserRole.CUSTOMER;
    
    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        phone: phone ?? null,
        role: userRole,
      },
    });
    
    // If service provider or parts trader, create additional profile
    if (userRole === UserRole.SERVICE_PROVIDER && country) {
      // Find region
      const region = await prisma.region.findFirst({
        where: { 
          OR: [
            { countryCode: country },
            { subdomain: country?.toLowerCase() },
          ]
        },
      });
      
      if (region) {
        await prisma.serviceProvider.create({
          data: {
            userId: user.id,
            regionId: region.id,
            businessName: name,
            phone: phone ?? '',
            email: email,
          },
        });
      }
    } else if (userRole === UserRole.PARTS_TRADER && country) {
      // Find region
      const region = await prisma.region.findFirst({
        where: { 
          OR: [
            { countryCode: country },
            { subdomain: country?.toLowerCase() },
          ]
        },
      });
      
      if (region) {
        await prisma.partsTrader.create({
          data: {
            userId: user.id,
            regionId: region.id,
            businessName: name,
            phone: phone ?? '',
            email: email,
          },
        });
      }
    }
    
    return NextResponse.json(
      { 
        message: 'User created successfully',
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        }
      },
      { status: 201 }
    );
    
  } catch (error) {
    console.error('Signup error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}