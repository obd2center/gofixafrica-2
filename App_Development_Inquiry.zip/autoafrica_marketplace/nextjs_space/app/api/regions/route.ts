// Regions API Route
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const regions = await prisma.region.findMany({
      where: { isActive: true },
      orderBy: { countryName: 'asc' },
      select: {
        id: true,
        countryCode: true,
        countryName: true,
        subdomain: true,
        defaultLanguage: true,
        defaultCurrency: true,
        paymentMethods: true,
        flagEmoji: true,
      },
    });
    
    return NextResponse.json(regions);
  } catch (error) {
    console.error('Error fetching regions:', error);
    return NextResponse.json(
      { error: 'Failed to fetch regions' },
      { status: 500 }
    );
  }
}