import { prisma } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { Star, Package, DollarSign, Info, ShoppingCart } from "lucide-react";
import { getCurrencySymbol } from "@/lib/region";
import { getServerSession } from "next-auth";

export const dynamic = "force-dynamic";

export default async function PartDetailPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findFirst({
    where: {
      OR: [
        { slug: params?.slug },
        { id: params?.slug },
      ],
    },
    include: {
      trader: {
        include: {
          region: true,
        },
      },
      category: true,
    },
  });
  
  if (!product) {
    notFound();
  }
  
  const session = await getServerSession();
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div>
            <Card>
              <CardContent className="p-8">
                <div className="relative h-96 w-full bg-gray-100 rounded-lg mb-4">
                  <Image
                    src={product?.images?.[0] ?? '/placeholder.jpg'}
                    alt={product?.name ?? 'Product'}
                    fill
                    className="object-contain p-8"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Product Info */}
          <div>
            <div className="mb-4">
              {product?.brand && (
                <span className="text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded-full mr-2">
                  {product.brand}
                </span>
              )}
              <span className={`text-sm px-3 py-1 rounded-full ${
                product?.condition === 'NEW' ? 'bg-green-100 text-green-700' :
                product?.condition === 'USED' ? 'bg-yellow-100 text-yellow-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {product?.condition ?? ''}
              </span>
            </div>
            
            <h1 className="text-3xl font-bold mb-4">{product?.name ?? ''}</h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500 mr-1" />
                <span className="font-semibold text-lg">{product?.rating?.toFixed(1) ?? '0.0'}</span>
                <span className="text-gray-500 ml-1">({product?.totalReviews ?? 0} reviews)</span>
              </div>
            </div>
            
            <div className="mb-6">
              <p className="text-4xl font-bold text-orange-600">
                {getCurrencySymbol(product?.currency ?? 'USD')} {product?.price?.toLocaleString()}
              </p>
            </div>
            
            <Card className="mb-6">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-3">Product Details</h3>
                <div className="space-y-2 text-sm">
                  {product?.partNumber && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Part Number:</span>
                      <span className="font-medium">{product.partNumber}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Stock:</span>
                    <span className="font-medium">
                      {product?.stockQuantity ?? 0} available
                    </span>
                  </div>
                  {product?.compatibility && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Compatibility:</span>
                      <span className="font-medium text-right ml-4">{product.compatibility}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Min. Order:</span>
                    <span className="font-medium">{product?.minOrderQty ?? 1} unit(s)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Description</h3>
              <p className="text-gray-700 leading-relaxed">
                {product?.description ?? ''}
              </p>
            </div>
            
            <Card className="mb-6">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Sold by</h3>
                <p className="text-lg font-medium">{product?.trader?.businessName ?? ''}</p>
                {product?.trader?.isVerified && (
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full mt-2 inline-block">
                    ✓ Verified Trader
                  </span>
                )}
              </CardContent>
            </Card>
            
            <div className="space-y-3">
              {session ? (
                <Button className="w-full bg-orange-500 hover:bg-orange-600" size="lg">
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Add to Cart
                </Button>
              ) : (
                <Link href="/auth/login" className="block">
                  <Button className="w-full bg-orange-500 hover:bg-orange-600" size="lg">
                    Sign in to Purchase
                  </Button>
                </Link>
              )}
              
              <Link href="/rfq/new" className="block">
                <Button variant="outline" className="w-full" size="lg">
                  <Info className="w-5 h-5 mr-2" />
                  Request Custom Quote
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}