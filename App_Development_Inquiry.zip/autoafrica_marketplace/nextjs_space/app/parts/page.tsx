import { prisma } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { Star, Package, DollarSign, Tag } from "lucide-react";
import { getCurrencySymbol } from "@/lib/region";

export const dynamic = "force-dynamic";

export default async function PartsPage() {
  const products = await prisma.product.findMany({
    where: { isActive: true },
    include: {
      trader: {
        include: {
          region: true,
        },
      },
      category: true,
    },
    orderBy: { rating: 'desc' },
    take: 20,
  });
  
  const categories = await prisma.category.findMany({
    where: { isActive: true },
    orderBy: { name: 'asc' },
    take: 10,
  });
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Auto Parts Marketplace
            </h1>
            <p className="text-gray-600">
              Find genuine and quality auto parts from trusted traders
            </p>
          </div>
          <Link href="/rfq/new">
            <Button className="bg-orange-500 hover:bg-orange-600">
              Request Quote (RFQ)
            </Button>
          </Link>
        </div>
        
        
        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products?.map((product) => (
            <Link key={product?.id} href={`/parts/${product?.slug ?? product?.id}`}>
              <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                <div className="relative h-48 w-full bg-gray-100">
                  <Image
                    src={product?.images?.[0] ?? '/placeholder.jpg'}
                    alt={product?.name ?? 'Product'}
                    fill
                    className="object-contain p-4 rounded-t-lg"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                  />
                </div>
                <CardContent className="p-4">
                  {product?.brand && (
                    <div className="mb-2">
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                        {product.brand}
                      </span>
                    </div>
                  )}
                  <h3 className="font-bold mb-1 line-clamp-2 text-sm">
                    {product?.name ?? ''}
                  </h3>
                  <p className="text-gray-600 text-xs mb-3 line-clamp-1">
                    {product?.trader?.businessName ?? ''}
                  </p>
                  
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center text-sm font-bold text-orange-600">
                      <DollarSign className="w-4 h-4 mr-1" />
                      {getCurrencySymbol(product?.currency ?? 'USD')} {product?.price?.toLocaleString()}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center">
                      <Star className="w-3 h-3 text-yellow-500 fill-yellow-500 mr-1" />
                      <span>{product?.rating?.toFixed(1) ?? '0.0'}</span>
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Package className="w-3 h-3 mr-1" />
                      {product?.stockQuantity ?? 0} in stock
                    </div>
                  </div>
                  
                  {product?.condition && (
                    <div className="mt-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        product.condition === 'NEW' ? 'bg-green-100 text-green-700' :
                        product.condition === 'USED' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {product.condition}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
        
        {products?.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No parts found. Check back soon!</p>
          </div>
        )}
      </div>
    </div>
  );
}