import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
  Package,
  Calendar,
  Star,
  TrendingUp,
  Wrench,
  FileText,
  Plus,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/login");
  }
  
  const userEmail = (session?.user as any)?.email ?? '';
  const userRole = (session?.user as any)?.role ?? 'CUSTOMER';
  
  // Fetch user data
  const user = await prisma.user.findUnique({
    where: { email: userEmail },
    include: {
      serviceProvider: true,
      partsTrader: true,
      bookings: {
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: {
          service: true,
          provider: true,
        },
      },
      rfqs: {
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: {
          trader: true,
        },
      },
      ecuOrders: {
        take: 5,
        orderBy: { createdAt: 'desc' },
      },
    },
  });
  
  // Stats based on role
  let stats: any[] = [];
  
  if (userRole === 'CUSTOMER') {
    stats = [
      {
        title: 'Total Bookings',
        value: user?.bookings?.length ?? 0,
        icon: Calendar,
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
      },
      {
        title: 'Active RFQs',
        value: user?.rfqs?.filter((r) => r?.status === 'OPEN')?.length ?? 0,
        icon: FileText,
        color: 'text-green-500',
        bgColor: 'bg-green-50',
      },
      {
        title: 'ECU Orders',
        value: user?.ecuOrders?.length ?? 0,
        icon: Package,
        color: 'text-purple-500',
        bgColor: 'bg-purple-50',
      },
    ];
  } else if (userRole === 'SERVICE_PROVIDER') {
    const providerStats = await prisma.serviceProvider.findUnique({
      where: { userId: user?.id ?? '' },
      include: {
        services: true,
        bookings: true,
        reviews: true,
      },
    });
    
    stats = [
      {
        title: 'Total Services',
        value: providerStats?.services?.length ?? 0,
        icon: Wrench,
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
      },
      {
        title: 'Total Bookings',
        value: providerStats?.bookings?.length ?? 0,
        icon: Calendar,
        color: 'text-green-500',
        bgColor: 'bg-green-50',
      },
      {
        title: 'Average Rating',
        value: providerStats?.rating?.toFixed(1) ?? '0.0',
        icon: Star,
        color: 'text-yellow-500',
        bgColor: 'bg-yellow-50',
      },
      {
        title: 'Total Reviews',
        value: providerStats?.reviews?.length ?? 0,
        icon: FileText,
        color: 'text-purple-500',
        bgColor: 'bg-purple-50',
      },
    ];
  } else if (userRole === 'PARTS_TRADER') {
    const traderStats = await prisma.partsTrader.findUnique({
      where: { userId: user?.id ?? '' },
      include: {
        products: true,
        rfqs: true,
        reviews: true,
      },
    });
    
    stats = [
      {
        title: 'Total Products',
        value: traderStats?.products?.length ?? 0,
        icon: Package,
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
      },
      {
        title: 'RFQ Requests',
        value: traderStats?.rfqs?.length ?? 0,
        icon: FileText,
        color: 'text-green-500',
        bgColor: 'bg-green-50',
      },
      {
        title: 'Average Rating',
        value: traderStats?.rating?.toFixed(1) ?? '0.0',
        icon: Star,
        color: 'text-yellow-500',
        bgColor: 'bg-yellow-50',
      },
      {
        title: 'Total Reviews',
        value: traderStats?.reviews?.length ?? 0,
        icon: TrendingUp,
        color: 'text-purple-500',
        bgColor: 'bg-purple-50',
      },
    ];
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-1">
              Welcome back, {user?.name ?? 'User'}!
            </p>
          </div>
          
          {userRole === 'SERVICE_PROVIDER' && (
            <Link href="/services/new">
              <Button className="bg-orange-500 hover:bg-orange-600">
                <Plus className="w-4 h-4 mr-2" />
                Add Service
              </Button>
            </Link>
          )}
          
          {userRole === 'PARTS_TRADER' && (
            <Link href="/products/new">
              <Button className="bg-orange-500 hover:bg-orange-600">
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </Link>
          )}
        </div>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats?.map((stat) => {
            const Icon = stat?.icon ?? Package;
            return (
              <Card key={stat?.title}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat?.title ?? ''}</p>
                      <p className="text-3xl font-bold">{stat?.value ?? 0}</p>
                    </div>
                    <div className={`${stat?.bgColor ?? 'bg-gray-50'} p-3 rounded-lg`}>
                      <Icon className={`w-6 h-6 ${stat?.color ?? 'text-gray-500'}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
        
        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Customer Recent Bookings */}
          {userRole === 'CUSTOMER' && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Bookings</CardTitle>
              </CardHeader>
              <CardContent>
                {user?.bookings?.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    No bookings yet. <Link href="/services" className="text-orange-500 hover:underline">Browse services</Link>
                  </p>
                ) : (
                  <div className="space-y-4">
                    {user?.bookings?.map((booking) => (
                      <div key={booking?.id} className="flex justify-between items-start border-b pb-4 last:border-0">
                        <div>
                          <p className="font-medium">{booking?.service?.name ?? ''}</p>
                          <p className="text-sm text-gray-600">{booking?.provider?.businessName ?? ''}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(booking?.bookingDate ?? '')?.toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          booking?.status === 'COMPLETED' ? 'bg-green-100 text-green-700' :
                          booking?.status === 'CONFIRMED' ? 'bg-blue-100 text-blue-700' :
                          booking?.status === 'CANCELLED' ? 'bg-red-100 text-red-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>
                          {booking?.status ?? ''}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          
          {/* Customer Recent RFQs */}
          {userRole === 'CUSTOMER' && (
            <Card>
              <CardHeader>
                <CardTitle>Recent RFQs</CardTitle>
              </CardHeader>
              <CardContent>
                {user?.rfqs?.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    No RFQs yet. <Link href="/rfq/new" className="text-orange-500 hover:underline">Create one</Link>
                  </p>
                ) : (
                  <div className="space-y-4">
                    {user?.rfqs?.map((rfq) => (
                      <div key={rfq?.id} className="flex justify-between items-start border-b pb-4 last:border-0">
                        <div>
                          <p className="font-medium">{rfq?.title ?? ''}</p>
                          {rfq?.trader && (
                            <p className="text-sm text-gray-600">{rfq?.trader?.businessName ?? ''}</p>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(rfq?.createdAt ?? '')?.toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          rfq?.status === 'QUOTED' ? 'bg-green-100 text-green-700' :
                          rfq?.status === 'OPEN' ? 'bg-blue-100 text-blue-700' :
                          rfq?.status === 'ACCEPTED' ? 'bg-purple-100 text-purple-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {rfq?.status ?? ''}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
        
        {/* Quick Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {userRole === 'CUSTOMER' && (
                <>
                  <Link href="/services">
                    <Button variant="outline" className="w-full">
                      <Wrench className="w-4 h-4 mr-2" />
                      Browse Services
                    </Button>
                  </Link>
                  <Link href="/parts">
                    <Button variant="outline" className="w-full">
                      <Package className="w-4 h-4 mr-2" />
                      Browse Parts
                    </Button>
                  </Link>
                  <Link href="/ecu">
                    <Button variant="outline" className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      ECU Services
                    </Button>
                  </Link>
                </>
              )}
              
              {userRole === 'SERVICE_PROVIDER' && (
                <>
                  <Link href="/services/new">
                    <Button variant="outline" className="w-full">
                      <Plus className="w-4 h-4 mr-2" />
                      Add New Service
                    </Button>
                  </Link>
                  <Link href="/bookings">
                    <Button variant="outline" className="w-full">
                      <Calendar className="w-4 h-4 mr-2" />
                      View Bookings
                    </Button>
                  </Link>
                </>
              )}
              
              {userRole === 'PARTS_TRADER' && (
                <>
                  <Link href="/products/new">
                    <Button variant="outline" className="w-full">
                      <Plus className="w-4 h-4 mr-2" />
                      Add New Product
                    </Button>
                  </Link>
                  <Link href="/rfq">
                    <Button variant="outline" className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      View RFQs
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}