"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Button } from "@/components/ui/button";
import { Car, Menu, X } from "lucide-react";

// Dynamically import auth-dependent content
const NavbarAuth = dynamic(() => import("./navbar-auth"), {
  ssr: false,
  loading: () => (
    <div className="hidden md:flex items-center space-x-3">
      <Link href="/auth/login">
        <Button variant="ghost" size="sm">
          Sign In
        </Button>
      </Link>
      <Link href="/auth/signup">
        <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
          Sign Up
        </Button>
      </Link>
    </div>
  ),
});

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  return (
    <nav className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="bg-orange-500 p-2 rounded-lg">
              <Car className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">AutoAfrica</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/services" className="text-gray-700 hover:text-orange-500 transition">
              Services
            </Link>
            <Link href="/parts" className="text-gray-700 hover:text-orange-500 transition">
              Parts
            </Link>
            <Link href="/ecu" className="text-gray-700 hover:text-orange-500 transition">
              ECU Services
            </Link>
            
            <NavbarAuth />
          </div>
          
          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-4 space-y-3">
            <Link
              href="/services"
              className="block py-2 text-gray-700 hover:text-orange-500"
              onClick={() => setMobileMenuOpen(false)}
            >
              Services
            </Link>
            <Link
              href="/parts"
              className="block py-2 text-gray-700 hover:text-orange-500"
              onClick={() => setMobileMenuOpen(false)}
            >
              Parts
            </Link>
            <Link
              href="/ecu"
              className="block py-2 text-gray-700 hover:text-orange-500"
              onClick={() => setMobileMenuOpen(false)}
            >
              ECU Services
            </Link>
            
            <div className="space-y-2 pt-2">
              <Link href="/auth/login" className="block" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="outline" className="w-full">
                  Sign In
                </Button>
              </Link>
              <Link href="/auth/signup" className="block" onClick={() => setMobileMenuOpen(false)}>
                <Button className="w-full bg-orange-500 hover:bg-orange-600">
                  Sign Up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
