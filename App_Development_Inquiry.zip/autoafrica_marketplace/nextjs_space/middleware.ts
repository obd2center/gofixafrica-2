// Middleware for region detection and auth protection
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // Get region from host
  const host = request.headers.get('host') ?? '';
  const subdomain = getSubdomainFromUrl(host);
  
  // Add region to headers for use in API routes and pages
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-region-subdomain', subdomain);
  
  // Protected routes that require authentication
  const protectedPaths = ['/dashboard', '/bookings', '/services/new', '/products/new', '/ecu', '/rfq'];
  const isProtectedPath = protectedPaths.some(path => pathname?.startsWith(path));
  
  if (isProtectedPath) {
    const token = await getToken({ req: request, secret: process.env.NEXTAUTH_SECRET });
    
    if (!token) {
      const loginUrl = new URL('/auth/login', request.url);
      loginUrl.searchParams.set('callbackUrl', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }
  
  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

function getSubdomainFromUrl(host: string): string {
  const parts = host?.split('.') ?? [];
  
  // localhost or direct IP
  if (parts?.length <= 1 || host?.includes('localhost')) {
    return 'ke'; // Default to Kenya
  }
  
  return parts?.[0] ?? 'ke';
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - api/auth (NextAuth routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files
     */
    '/((?!api/auth|_next/static|_next/image|favicon.ico|og-image.png|robots.txt).*)',
  ],
};