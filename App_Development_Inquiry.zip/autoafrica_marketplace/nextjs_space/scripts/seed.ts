// Database Seed Script
import { PrismaClient, UserRole, BookingStatus, RFQStatus, PaymentStatus, PaymentMethod, ProductCondition } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting seed...');
  
  // Clean existing data
  console.log('[Clean] Cleaning existing data...');
  await prisma.notification.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.review.deleteMany();
  await prisma.rFQItem.deleteMany();
  await prisma.rFQ.deleteMany();
  await prisma.eCUOrder.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.product.deleteMany();
  await prisma.service.deleteMany();
  await prisma.partsTrader.deleteMany();
  await prisma.serviceProvider.deleteMany();
  await prisma.category.deleteMany();
  await prisma.session.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();
  await prisma.region.deleteMany();
  
  // Create Regions
  console.log('[Regions] Creating regions...');
  const regions = await Promise.all([
    prisma.region.create({
      data: {
        countryCode: 'KE',
        countryName: 'Kenya',
        subdomain: 'ke',
        defaultLanguage: 'en',
        defaultCurrency: 'KES',
        paymentMethods: ['MPESA', 'FLUTTERWAVE'],
        flagEmoji: 'KE',
        timezone: 'Africa/Nairobi',
      },
    }),
    prisma.region.create({
      data: {
        countryCode: 'NG',
        countryName: 'Nigeria',
        subdomain: 'ng',
        defaultLanguage: 'en',
        defaultCurrency: 'NGN',
        paymentMethods: ['PAYSTACK', 'FLUTTERWAVE'],
        flagEmoji: 'NG',
        timezone: 'Africa/Lagos',
      },
    }),
    prisma.region.create({
      data: {
        countryCode: 'ZA',
        countryName: 'South Africa',
        subdomain: 'za',
        defaultLanguage: 'en',
        defaultCurrency: 'ZAR',
        paymentMethods: ['PAYSTACK', 'FLUTTERWAVE'],
        flagEmoji: 'ZA',
        timezone: 'Africa/Johannesburg',
      },
    }),
    prisma.region.create({
      data: {
        countryCode: 'GH',
        countryName: 'Ghana',
        subdomain: 'gh',
        defaultLanguage: 'en',
        defaultCurrency: 'GHS',
        paymentMethods: ['PAYSTACK', 'FLUTTERWAVE'],
        flagEmoji: 'GH',
        timezone: 'Africa/Accra',
      },
    }),
    prisma.region.create({
      data: {
        countryCode: 'TZ',
        countryName: 'Tanzania',
        subdomain: 'tz',
        defaultLanguage: 'sw',
        defaultCurrency: 'TZS',
        paymentMethods: ['MPESA', 'FLUTTERWAVE'],
        flagEmoji: 'TZ',
        timezone: 'Africa/Dar_es_Salaam',
      },
    }),
  ]);
  console.log(`[OK] Created ${regions?.length ?? 0} regions`);
  
  // Create Categories
  console.log('[Categories] Creating categories...');
  const categories = await Promise.all([
    prisma.category.create({
      data: {
        name: 'General Repair & Maintenance',
        slug: 'general-repair',
        description: 'Oil changes, inspections, tune-ups',
        icon: 'wrench',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Engine Services',
        slug: 'engine-services',
        description: 'Engine diagnostics, repair, and rebuilding',
        icon: 'cog',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Brake Services',
        slug: 'brake-services',
        description: 'Brake pad replacement, rotor resurfacing',
        icon: 'disc',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Electrical Systems',
        slug: 'electrical-systems',
        description: 'Battery, alternator, starter services',
        icon: 'zap',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Suspension & Steering',
        slug: 'suspension-steering',
        description: 'Shock absorbers, alignment, power steering',
        icon: 'move',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Transmission',
        slug: 'transmission',
        description: 'Transmission repair and fluid services',
        icon: 'settings',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Tires & Wheels',
        slug: 'tires-wheels',
        description: 'Tire sales, mounting, balancing',
        icon: 'circle',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Air Conditioning',
        slug: 'air-conditioning',
        description: 'AC repair, recharge, and maintenance',
        icon: 'wind',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Body Work & Paint',
        slug: 'body-work-paint',
        description: 'Dent repair, painting, detailing',
        icon: 'paintbrush',
      },
    }),
    prisma.category.create({
      data: {
        name: 'Diagnostic Services',
        slug: 'diagnostic-services',
        description: 'Computer diagnostics, error code reading',
        icon: 'activity',
      },
    }),
  ]);
  console.log(`[OK] Created ${categories?.length ?? 0} categories`);
  
  // Create Test Admin User (required)
  console.log('[User] Creating test admin user...');
  const adminPassword = await bcrypt.hash('johndoe123', 10);
  const adminUser = await prisma.user.create({
    data: {
      email: 'john@doe.com',
      password: adminPassword,
      name: 'Admin User',
      phone: '+254700000000',
      role: UserRole.ADMIN,
      isActive: true,
    },
  });
  console.log(`[OK] Created admin user: ${adminUser?.email ?? ''}`);
  
  // Create Sample Users
  console.log('[Users] Creating sample users...');
  const password = await bcrypt.hash('password123', 10);
  
  const customer1 = await prisma.user.create({
    data: {
      email: 'customer@example.com',
      password,
      name: 'Jane Wanjiku',
      phone: '+254712345678',
      role: UserRole.CUSTOMER,
    },
  });
  
  const provider1User = await prisma.user.create({
    data: {
      email: 'provider1@example.com',
      password,
      name: 'AutoFix Garage',
      phone: '+254723456789',
      role: UserRole.SERVICE_PROVIDER,
    },
  });
  
  const provider2User = await prisma.user.create({
    data: {
      email: 'provider2@example.com',
      password,
      name: 'Premium Motors',
      phone: '+254734567890',
      role: UserRole.SERVICE_PROVIDER,
    },
  });
  
  const trader1User = await prisma.user.create({
    data: {
      email: 'trader1@example.com',
      password,
      name: 'Quality Parts Ltd',
      phone: '+254745678901',
      role: UserRole.PARTS_TRADER,
    },
  });
  
  const trader2User = await prisma.user.create({
    data: {
      email: 'trader2@example.com',
      password,
      name: 'AutoParts Direct',
      phone: '+254756789012',
      role: UserRole.PARTS_TRADER,
    },
  });
  
  console.log('[OK] Created sample users');
  
  // Create Service Providers
  console.log('[Services] Creating service providers...');
  const provider1 = await prisma.serviceProvider.create({
    data: {
      userId: provider1User.id,
      regionId: regions[0]?.id ?? '',
      businessName: 'AutoFix Garage',
      businessType: 'General Repair Shop',
      description: 'Professional auto repair services with 15+ years of experience. We specialize in engine diagnostics, brake services, and general maintenance.',
      logo: 'https://i.ytimg.com/vi/rcFWBx7LvLM/maxresdefault.jpg',
      coverImage: 'https://www.sunsethillssubaru.com/blogs/4580/wp-content/uploads/2025/03/BLOG1.jpg',
      phone: '+254723456789',
      email: 'info@autofixgarage.ke',
      address: 'Mombasa Road, Industrial Area, Nairobi',
      latitude: -1.3194,
      longitude: 36.8497,
      isVerified: true,
      rating: 4.8,
      totalReviews: 142,
      totalBookings: 356,
    },
  });
  
  const provider2 = await prisma.serviceProvider.create({
    data: {
      userId: provider2User.id,
      regionId: regions[0]?.id ?? '',
      businessName: 'Premium Motors',
      businessType: 'Specialized Service Center',
      description: 'High-end automotive service center specializing in European and Japanese vehicles. State-of-the-art diagnostic equipment.',
      logo: 'https://i.ytimg.com/vi/Vys-iUboDPw/maxresdefault.jpg',
      coverImage: 'https://i.ytimg.com/vi/rcFWBx7LvLM/maxresdefault.jpg',
      phone: '+254734567890',
      email: 'service@premiummotors.ke',
      address: 'Waiyaki Way, Westlands, Nairobi',
      latitude: -1.2648,
      longitude: 36.8065,
      isVerified: true,
      rating: 4.9,
      totalReviews: 98,
      totalBookings: 234,
    },
  });
  
  console.log('[OK] Created service providers');
  
  // Create Services
  console.log('[Creating] Creating services...');
  const services = await Promise.all([
    prisma.service.create({
      data: {
        providerId: provider1.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[0]?.id ?? '',
        name: 'Full Service & Oil Change',
        slug: 'full-service-oil-change',
        description: 'Complete vehicle service including oil change, filter replacement, brake check, tire rotation, and multi-point inspection.',
        images: ['https://www.sunsethillssubaru.com/blogs/4580/wp-content/uploads/2025/03/BLOG1.jpg'],
        price: 5500,
        priceType: 'fixed',
        duration: '2 hours',
        tags: ['oil-change', 'maintenance', 'inspection'],
        rating: 4.7,
        totalReviews: 45,
        viewCount: 234,
      },
    }),
    prisma.service.create({
      data: {
        providerId: provider1.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[2]?.id ?? '',
        name: 'Brake Pad Replacement',
        slug: 'brake-pad-replacement',
        description: 'Professional brake pad replacement service. Includes inspection of rotors, calipers, and brake fluid.',
        images: ['https://www.buybrakes.com/images/product/ebc/bkt-aba/ebc-s4kf1042-unn-6.jpg'],
        price: 8500,
        priceType: 'fixed',
        duration: '1.5 hours',
        tags: ['brakes', 'safety', 'replacement'],
        rating: 4.9,
        totalReviews: 67,
        viewCount: 456,
      },
    }),
    prisma.service.create({
      data: {
        providerId: provider2.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[9]?.id ?? '',
        name: 'Computer Diagnostics',
        slug: 'computer-diagnostics',
        description: 'Advanced computer diagnostics using professional-grade equipment. Identify and resolve engine issues, error codes, and performance problems.',
        images: ['https://i.ytimg.com/vi/Vys-iUboDPw/maxresdefault.jpg'],
        price: 3500,
        priceType: 'fixed',
        duration: '1 hour',
        tags: ['diagnostics', 'electronics', 'troubleshooting'],
        rating: 5.0,
        totalReviews: 89,
        viewCount: 678,
      },
    }),
    prisma.service.create({
      data: {
        providerId: provider2.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[1]?.id ?? '',
        name: 'Engine Tune-Up',
        slug: 'engine-tune-up',
        description: 'Complete engine tune-up service including spark plug replacement, air filter, fuel filter, and throttle body cleaning.',
        images: ['https://i.ytimg.com/vi/rcFWBx7LvLM/maxresdefault.jpg'],
        price: 12000,
        priceType: 'fixed',
        duration: '3 hours',
        tags: ['engine', 'performance', 'maintenance'],
        rating: 4.8,
        totalReviews: 34,
        viewCount: 289,
      },
    }),
  ]);
  
  console.log(`[OK] Created ${services?.length ?? 0} services`);
  
  // Create Parts Traders
  console.log('[Traders] Creating parts traders...');
  const trader1 = await prisma.partsTrader.create({
    data: {
      userId: trader1User.id,
      regionId: regions[0]?.id ?? '',
      businessName: 'Quality Parts Ltd',
      businessType: 'Parts Wholesaler & Retailer',
      description: 'Leading supplier of genuine and OEM auto parts. We stock parts for all major brands with fast delivery across Kenya.',
      logo: 'https://m.media-amazon.com/images/I/31efoOY8i3L.jpg',
      phone: '+254745678901',
      email: 'sales@qualityparts.ke',
      address: 'Kirinyaga Road, Industrial Area, Nairobi',
      latitude: -1.3203,
      longitude: 36.8483,
      isVerified: true,
      rating: 4.7,
      totalReviews: 234,
      totalOrders: 1245,
    },
  });
  
  const trader2 = await prisma.partsTrader.create({
    data: {
      userId: trader2User.id,
      regionId: regions[0]?.id ?? '',
      businessName: 'AutoParts Direct',
      businessType: 'Online Parts Retailer',
      description: 'Online automotive parts store with competitive prices. Specializing in engine components, filters, and maintenance parts.',
      logo: 'https://m.media-amazon.com/images/I/71Hw8a8FS3L.jpg',
      phone: '+254756789012',
      email: 'info@autopartsdirect.ke',
      address: 'Ngong Road, Nairobi',
      latitude: -1.2930,
      longitude: 36.7820,
      isVerified: true,
      rating: 4.6,
      totalReviews: 167,
      totalOrders: 892,
    },
  });
  
  console.log('[OK] Created parts traders');
  
  // Create Products
  console.log('[Products] Creating products...');
  const products = await Promise.all([
    prisma.product.create({
      data: {
        traderId: trader1.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[2]?.id ?? '',
        name: 'Premium Brake Pads Set',
        slug: 'premium-brake-pads-set',
        description: 'High-performance ceramic brake pads. Low dust, quiet operation, excellent stopping power. Fits most Toyota, Nissan models.',
        images: ['https://www.buybrakes.com/images/product/ebc/bkt-aba/ebc-s4kf1042-unn-6.jpg'],
        price: 4500,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'Brembo',
        partNumber: 'BP-2045',
        compatibility: 'Toyota Camry, Corolla, RAV4 (2015-2023)',
        stockQuantity: 45,
        tags: ['brakes', 'safety', 'ceramic'],
        rating: 4.8,
        totalReviews: 56,
        viewCount: 342,
      },
    }),
    prisma.product.create({
      data: {
        traderId: trader1.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[0]?.id ?? '',
        name: 'Synthetic Engine Oil 5W-30',
        slug: 'synthetic-engine-oil-5w30',
        description: 'Premium fully synthetic engine oil. Extended drain intervals, superior protection in extreme conditions. 5L container.',
        images: ['https://m.media-amazon.com/images/I/31efoOY8i3L.jpg'],
        price: 3200,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'Castrol',
        partNumber: 'OIL-5W30-5L',
        compatibility: 'Universal - Most modern engines',
        stockQuantity: 120,
        tags: ['oil', 'maintenance', 'synthetic'],
        rating: 4.9,
        totalReviews: 89,
        viewCount: 567,
      },
    }),
    prisma.product.create({
      data: {
        traderId: trader2.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[3]?.id ?? '',
        name: 'Car Battery 70Ah',
        slug: 'car-battery-70ah',
        description: 'Maintenance-free car battery with 70Ah capacity. 24-month warranty, excellent cranking power, leak-proof design.',
        images: ['https://m.media-amazon.com/images/I/71Hw8a8FS3L.jpg'],
        price: 12500,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'Bosch',
        partNumber: 'BAT-70AH',
        compatibility: 'Most sedans and small SUVs',
        stockQuantity: 28,
        tags: ['battery', 'electrical', 'power'],
        rating: 4.7,
        totalReviews: 43,
        viewCount: 298,
      },
    }),
    prisma.product.create({
      data: {
        traderId: trader2.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[6]?.id ?? '',
        name: 'All-Season Tire 195/65R15',
        slug: 'all-season-tire-195-65r15',
        description: 'Quality all-season tire with excellent wet and dry traction. Long tread life, comfortable ride. Single tire price.',
        images: ['https://cokertire.com/media/catalog/product/b/f/bfg_at_ta_ko2_001_pn004855_4.jpg'],
        price: 8500,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'Michelin',
        partNumber: 'TIRE-195-65R15',
        compatibility: 'Toyota Corolla, Honda Civic, Mazda 3',
        stockQuantity: 60,
        tags: ['tires', 'wheels', 'all-season'],
        rating: 4.8,
        totalReviews: 72,
        viewCount: 445,
      },
    }),
    prisma.product.create({
      data: {
        traderId: trader1.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[0]?.id ?? '',
        name: 'Engine Air Filter',
        slug: 'engine-air-filter',
        description: 'High-flow air filter for improved engine performance. Washable and reusable. Easy installation.',
        images: ['https://m.media-amazon.com/images/I/61QB10RPtWL.jpg'],
        price: 1500,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'K&N',
        partNumber: 'AF-33-2304',
        compatibility: 'Toyota, Nissan, Honda (various models)',
        stockQuantity: 85,
        tags: ['filter', 'air', 'performance'],
        rating: 4.6,
        totalReviews: 34,
        viewCount: 189,
      },
    }),
    prisma.product.create({
      data: {
        traderId: trader2.id,
        regionId: regions[0]?.id ?? '',
        categoryId: categories[1]?.id ?? '',
        name: 'Spark Plugs Set (4pc)',
        slug: 'spark-plugs-set-4pc',
        description: 'Iridium spark plugs for better fuel economy and performance. Set of 4. Long-lasting up to 100,000km.',
        images: ['https://m.media-amazon.com/images/I/71dMgbxgaOL.jpg'],
        price: 2800,
        currency: 'KES',
        condition: ProductCondition.NEW,
        brand: 'NGK',
        partNumber: 'SP-4789',
        compatibility: '4-cylinder engines',
        stockQuantity: 95,
        tags: ['spark-plugs', 'ignition', 'performance'],
        rating: 4.9,
        totalReviews: 67,
        viewCount: 312,
      },
    }),
  ]);
  
  console.log(`[OK] Created ${products?.length ?? 0} products`);
  
  // Create Sample Bookings
  console.log('[Bookings] Creating sample bookings...');
  const booking1 = await prisma.booking.create({
    data: {
      userId: customer1.id,
      providerId: provider1.id,
      serviceId: services[0]?.id ?? '',
      regionId: regions[0]?.id ?? '',
      bookingDate: new Date('2025-01-15T10:00:00'),
      status: BookingStatus.COMPLETED,
      customerName: 'Jane Wanjiku',
      customerPhone: '+254712345678',
      customerEmail: 'customer@example.com',
      message: 'Need a full service for my Toyota Corolla',
      price: 5500,
      paymentStatus: PaymentStatus.COMPLETED,
      paymentMethod: PaymentMethod.MPESA,
    },
  });
  
  const booking2 = await prisma.booking.create({
    data: {
      userId: customer1.id,
      providerId: provider2.id,
      serviceId: services[2]?.id ?? '',
      regionId: regions[0]?.id ?? '',
      bookingDate: new Date('2025-01-20T14:00:00'),
      status: BookingStatus.CONFIRMED,
      customerName: 'Jane Wanjiku',
      customerPhone: '+254712345678',
      customerEmail: 'customer@example.com',
      message: 'Check engine light is on',
      price: 3500,
      paymentStatus: PaymentStatus.PENDING,
    },
  });
  
  console.log('[OK] Created sample bookings');
  
  // Create Sample RFQs
  console.log('[RFQs] Creating sample RFQs...');
  const rfq1 = await prisma.rFQ.create({
    data: {
      userId: customer1.id,
      regionId: regions[0]?.id ?? '',
      traderId: trader1.id,
      title: 'Need brake pads for Honda Accord 2018',
      description: 'Looking for genuine or OEM brake pads for all 4 wheels. Please provide quote with installation if possible.',
      vehicleInfo: JSON.stringify({ make: 'Honda', model: 'Accord', year: 2018 }),
      urgency: 'medium',
      status: RFQStatus.QUOTED,
      quotedPrice: 18000,
      quotedBy: 'Quality Parts Ltd',
      quoteNotes: 'We have genuine Honda brake pads in stock. Can install at our workshop for additional 2000 KES.',
      responseDate: new Date('2025-01-12T09:00:00'),
      expiryDate: new Date('2025-01-25T00:00:00'),
    },
  });
  
  await prisma.rFQItem.create({
    data: {
      rfqId: rfq1.id,
      productId: products[0]?.id ?? null,
      partName: 'Brake Pads Set (Front & Rear)',
      quantity: 2,
      description: 'One set for front, one for rear',
    },
  });
  
  console.log('[OK] Created sample RFQs');
  
  // Create Sample Reviews
  console.log('[Reviews] Creating sample reviews...');
  await prisma.review.create({
    data: {
      userId: customer1.id,
      providerId: provider1.id,
      bookingId: booking1.id,
      rating: 5,
      title: 'Excellent service!',
      comment: 'Very professional team. The service was thorough and completed on time. Highly recommend!',
      categories: ['quality', 'timeliness', 'communication'],
      isVerified: true,
    },
  });
  
  await prisma.review.create({
    data: {
      userId: customer1.id,
      traderId: trader1.id,
      rating: 5,
      title: 'Great quality parts',
      comment: 'Received genuine parts at a good price. Fast delivery and helpful staff.',
      categories: ['quality', 'price', 'delivery'],
      isVerified: true,
    },
  });
  
  console.log('[OK] Created sample reviews');
  
  console.log('[Success] Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('[Error] Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });