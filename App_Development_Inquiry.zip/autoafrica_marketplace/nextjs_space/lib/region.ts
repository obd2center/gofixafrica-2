// Region Detection & Configuration
import { Region } from "@prisma/client";
import { prisma } from "./db";

export interface RegionData {
  id: string;
  countryCode: string;
  countryName: string;
  subdomain: string;
  defaultLanguage: string;
  defaultCurrency: string;
  paymentMethods: string[];
  flagEmoji?: string | null;
  timezone?: string | null;
}

// Extract subdomain from hostname
export function getSubdomainFromHost(host: string): string | null {
  const parts = host?.split('.') ?? [];
  
  // localhost or direct IP
  if (parts?.length <= 1 || host?.includes('localhost')) {
    return 'ke'; // Default to Kenya
  }
  
  // Extract subdomain (e.g., "ke" from "ke.autoafrica.com")
  return parts?.[0] ?? 'ke';
}

// Get region configuration from database
export async function getRegionBySubdomain(subdomain: string): Promise<RegionData | null> {
  try {
    const region = await prisma.region.findUnique({
      where: { subdomain },
    });
    
    return region;
  } catch (error) {
    console.error('Error fetching region:', error);
    return null;
  }
}

// Get all active regions
export async function getAllRegions(): Promise<RegionData[]> {
  try {
    const regions = await prisma.region.findMany({
      where: { isActive: true },
      orderBy: { countryName: 'asc' },
    });
    
    return regions;
  } catch (error) {
    console.error('Error fetching regions:', error);
    return [];
  }
}

// Currency symbols
export function getCurrencySymbol(currencyCode: string): string {
  const symbols: Record<string, string> = {
    'KES': 'KSh',
    'NGN': '₦',
    'ZAR': 'R',
    'USD': '$',
    'GHS': 'GH₵',
    'TZS': 'TSh',
    'UGX': 'USh',
  };
  return symbols[currencyCode] ?? currencyCode;
}

// Format currency
export function formatCurrency(amount: number, currencyCode: string): string {
  const symbol = getCurrencySymbol(currencyCode);
  return `${symbol} ${amount?.toLocaleString() ?? '0'}`;
}